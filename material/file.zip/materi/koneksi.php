<?php
$host = "localhost";
$user = "id16357617_fadli";
$pass = "Androidstack123!";
$db = "id16357617_db_android";

$konek = mysqli_connect($host, $user, $pass, $db) or die ("Database mysql tidak terhubung");