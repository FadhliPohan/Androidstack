<?php
$koneksi = mysql_connect('localhost','root','') or die(mysql_error());</pre>
$db = mysql_select_db('kuis') or die (mysql_error());
?>